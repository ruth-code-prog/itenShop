import React, {Component, useCallback, useEffect, useState} from 'react';
import {ScrollView, StyleSheet, Text, View} from 'react-native';
import {
  BannerSlider,
  HeaderComponent,
  ListJerseys,
  ListLiga,
  PopupPoint,
  Tombol,
} from '../../components';
import {colors, fonts, getData} from '../../utils';
import {Jarak} from '../../components';
import {connect, useDispatch, useSelector} from 'react-redux';
import {getListLiga} from '../../actions/LigaAction';
import {limitJersey} from '../../actions/JerseyAction';
import Notif from '../Notif';
import {useFocusEffect, useNavigation} from '@react-navigation/core';
import FIREBASE from '../../config/FIREBASE';

const Home = props => {
  const [bannerData, setBannerData] = useState([]);
  const [pointPopup, setPointPopup] = useState(false);
  const [point, setPoint] = useState(0);

  const navigation = useNavigation();
  const dispatch = useDispatch();

  useFocusEffect(
    useCallback(() => {
      dispatch(getListLiga());
      dispatch(limitJersey());
      getImage();
    }, []),
  );

  useEffect(() => {
    checkUser();
  }, []);

  const getImage = () => {
    FIREBASE.database()
      .ref('desain_banner')
      .once('value', snapshot => {
        const data = snapshot.val();
        let arr = [];
        data.map(val => arr.push(val?.uri));

        setBannerData(arr);
      });
  };

  const checkUser = () => {
    getData('user').then(res => {
      if (res) {
        setPoint(res?.point);
        if (!pointPopup) {
          setPointPopup(true);
        }
      }
    });
  };

  return (
    <View style={styles.page}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <HeaderComponent navigation={navigation} page="Home" />
        <BannerSlider data={bannerData} />
        <View style={styles.pilihLiga}>
          <Text style={styles.label}>Kategori</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <ListLiga navigation={navigation} />
          </ScrollView>
        </View>

        <View style={styles.pilihJersey}>
          <Text style={styles.label}>
            Pilih <Text style={styles.boldLabel}>Produk</Text> Yang Anda
            Inginkan
          </Text>
          <ListJerseys navigation={navigation} />

          <Tombol title="Lihat Semua" type="text" padding={7} />
        </View>

        <Jarak height={100} />
      </ScrollView>
      <Notif />
      <PopupPoint
        point={point}
        visible={pointPopup}
        onClose={() => setPointPopup(false)}
      />
    </View>
  );
};

export default connect()(Home);

const styles = StyleSheet.create({
  page: {flex: 1, backgroundColor: colors.dark},
  pilihLiga: {
    marginHorizontal: 30,
    marginTop: 10,
  },
  pilihJersey: {
    marginHorizontal: 30,
    marginTop: 10,
  },
  label: {
    fontSize: 18,
    fontFamily: fonts.primary.regular,
    color: '#FFFFFF',
  },
  boldLabel: {
    fontSize: 18,
    fontFamily: fonts.primary.bold,
  },
});
