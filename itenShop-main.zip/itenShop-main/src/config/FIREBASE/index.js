import firebase from 'firebase';

firebase.initializeApp({
  apiKey: "AIzaSyBACqPrNkkYChpdNI25fuXdKuzCkh4_ciE",
  authDomain: "itenshop-eb709.firebaseapp.com",
  projectId: "itenshop-eb709",
  storageBucket: "itenshop-eb709.appspot.com",
  messagingSenderId: "552022496169",
  appId: "1:552022496169:web:8cc5b8cdddf8f6c146eab8"

});

const FIREBASE = firebase;

export default FIREBASE
