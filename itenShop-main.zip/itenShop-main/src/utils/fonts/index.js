export const fonts = {
    primary: {
        light: "PublicSans-Light",
        regular: "PublicSans-Regular",
        semibold: "PublicSans-SemiBold",
        bold: "PublicSans-Bold",
    }
}