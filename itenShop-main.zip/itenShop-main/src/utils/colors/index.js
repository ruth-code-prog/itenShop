export const colors = {
    primary: '#22668A',
    white: '#FFFFFF',
    secondary: '#6AB1D7',
    yellow: '#FFF6D5',
    yellow2: '#FEF1DE',
    yellow3: '#FBBC05',
    border: '#C4C4C4',
    dark: '#000000'
}