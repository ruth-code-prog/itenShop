import { FotoProfile } from "../../assets";

export const dummyProfile = {
    nama: 'Muhammad Afifuddin',
    email: 'afifbasya@gmail.com',
    nomerHp: '085712312333',
    alamat: 'Jl. Menoreh Tengah X/ 22 Sampangan',
    kota: 'Semarang',
    provinsi: 'Jawa Tengah',
    avatar: FotoProfile
};