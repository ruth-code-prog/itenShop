import React from 'react'
import { View } from 'react-native'

const Jarak = ({height, width}) => {
    return (
        <View style={{height: height, width: width }}/>
    )
}

export default Jarak
