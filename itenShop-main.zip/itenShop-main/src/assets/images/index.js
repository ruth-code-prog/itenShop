import Logo from './logo.svg'
import Ilustrasi from './ilustrasi.js'
import Slider1 from './slider1.png'
import Slider2 from './slider2.png'
import FotoProfile from './profile.jpg'
import IlustrasiRegister1 from './register1.js'
import IlustrasiRegister2 from './register2.js'
import DefaultImage from './default.jpg'

export { Logo, Ilustrasi, Slider1, Slider2, FotoProfile, IlustrasiRegister1, IlustrasiRegister2, DefaultImage }