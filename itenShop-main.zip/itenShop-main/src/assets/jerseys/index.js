import ChelseaDepan from './chelsea1.png';
import ChelseaBelakang from './chelsea2.png';
import DortmundDepan from './dortmund1.png';
import DortmundBelakang from './dortmund2.png';
import JuveDepan from './juve1.png';
import JuveBelakang from './juve2.png';
import LeicesterDepan from './leicester1.png';
import LeicesterBelakang from './leicester2.png';
import LiverpoolDepan from './liverpool1.png';
import LiverpoolBelakang from './liverpool2.png';
import MadridDepan from './madrid1.png';
import MadridBelakang from './madrid2.png';
import MilanDepan from './milan1.png';
import MilanBelakang from './milan2.png';
import MunchenDepan from './munchen1.png';
import MunchenBelakang from './munchen2.png';

export {
  ChelseaDepan,
  ChelseaBelakang,
  DortmundBelakang,
  DortmundDepan,
  JuveBelakang,
  JuveDepan,
  LeicesterBelakang,
  LeicesterDepan,
  LiverpoolBelakang,
  LiverpoolDepan,
  MadridBelakang,
  MadridDepan,
  MilanBelakang,
  MilanDepan,
  MunchenDepan,
  MunchenBelakang,
};