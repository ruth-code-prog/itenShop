import SerieA from './seriea.png'
import LaLiga from './laliga.png'
import PremierLeague from './premierleague.png'
import BundesLiga from './bundesliga.png'

export { BundesLiga, LaLiga, PremierLeague, SerieA }